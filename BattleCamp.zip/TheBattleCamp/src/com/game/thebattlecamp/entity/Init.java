package com.game.thebattlecamp.entity;

public class Init {

	public static void main(String[] args) {
		new TesteFrame();
	}

}
