package com.game.thebattlecamp.entity;

import javax.swing.JFrame;

public class TesteFrame extends JFrame{

	public TesteFrame() {
		setVisible(true);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		
	}
}
